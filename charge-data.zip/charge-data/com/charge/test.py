# -*- encoding=utf8 -*-
__author__ = "xuzhenghua"

# import requests
# from bs4 import BeautifulSoup
# import time
# import re
# url = 'https://www.autohome.com.cn/ashx/index/GetHomeFindCar.ashx?type=1&brandid=33&v=1'
# #header必须是以字典的形式出现
# header = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36'}
# #s = requests.session()
# #请求时发生SSL验证失败，解决方法是让requests忽略对SSL证书的验证
# #在没有verify=False是会出现SSLError
# web_url = requests.get(url,headers=header,verify=False)
# # soup = BeautifulSoup(web_url.content,'lxml')
# print(web_url.text)
from com.charge.domain.AreaVillage import t_area_village

from com.charge.YYC.model.PrivatePile import PrivatePile

# privatePile = PrivatePile('1', '2', '3', '4', '5', '6', '7', '8', '9')
# privatePile2 = PrivatePile('1', '2', '3', '4', '5', '6', '7', '8', '9')
#
# print(privatePile.md5() == privatePile2.md5())

# 查询街道信息
for pile in t_area_village.select().order_by(t_area_village.sname.asc()).group_by(t_area_village.sname).limit(900).offset(33):
    print(pile.id, pile.sname)