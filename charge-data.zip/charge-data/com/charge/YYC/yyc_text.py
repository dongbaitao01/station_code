# -*- encoding=utf8 -*-
__author__ = "xuzhenghua"

from airtest.core.api import *
from airtest.cli.parser import cli_setup
from poco.drivers.android.uiautomation import AndroidUiautomationPoco

from com.charge.YYC.model.PrivatePile import PrivatePile
import time

poco = AndroidUiautomationPoco(use_airtest_input=True, screenshot_each_action=False)

if not cli_setup():
      auto_setup(__file__, logdir=True, devices=["android://127.0.0.1:5037/4df1af08?cap_method=MINICAP&&ori_method=MINICAPORI&&touch_method=MAXTOUCH",])


start_app("com.xpg.hssychargingpole")

# 关闭弹窗
if poco("com.xpg.hssychargingpole:id/tipsClose").exists():
    poco("com.xpg.hssychargingpole:id/tipsClose").click()

# 进入搜索页
poco("com.xpg.hssychargingpole:id/tv_Index_search").click()

# 点击输入框
poco("com.xpg.hssychargingpole:id/pilesearchET").click()

name = "万年花城一期"
# 输入地址
poco("com.xpg.hssychargingpole:id/pilesearchET").set_text(name)

# 点击搜索按钮
touch(Template(r"../image/tpl1635146173165.png", record_pos=(0.429, 0.856), resolution=(1080, 2340)))

# 点击目的地
poco(text="目的地").click()

# 点击第一个地址
poco("com.xpg.hssychargingpole:id/pileSearchLocationLL").wait(5)[0].click()

if isinstance(exists(Template(r"../image/tpl1635147502723.png", record_pos=(0.349, -0.906), resolution=(1080, 2340))), bool):
    # 设置筛选项
    poco("com.xpg.hssychargingpole:id/tv_SearchCharging_filter").click()
    touch(Template(r"../image/tpl1635146981250.png", record_pos=(-0.329, -0.571), resolution=(1080, 2340)))
    touch(Template(r"../image/tpl1635147118157.png", record_pos=(0.162, 0.608), resolution=(1080, 2340)))

reslist = []
checkList = []

# 读取私桩信息列表
pileList = poco("com.xpg.hssychargingpole:id/cardView").wait(5)

runSts = True
page = 1

while runSts:

    repeat = 0

    lengtn = 5
    # if len(pileList) < lengtn:
    #     lengtn = len(pileList)
    pileList = poco("com.xpg.hssychargingpole:id/cardView").wait(5)
    for num in range(0, lengtn):
        if page == 1:
            # 点击进入详情
            pileList[num].click()
        else:
            # 点击进入详情
            pileList[num+1].click()

        # 电站名称
        pile_name = poco("com.xpg.hssychargingpole:id/tv_ChargingHead_Title").wait(3).get_text()
        # 电站地址
        pile_address = ""
        if poco("com.xpg.hssychargingpole:id/tv_ChargingHead_Location").exists():
            pile_address = poco("com.xpg.hssychargingpole:id/tv_ChargingHead_Location").get_text()
        # 电桩类型
        pile_type = ""
        if poco("com.xpg.hssychargingpole:id/tvPileType").exists():
            pile_type = poco("com.xpg.hssychargingpole:id/tvPileType").get_text()
        # 电桩参数
        pile_param = ""
        if poco("com.xpg.hssychargingpole:id/tvConfig").exists():
            pile_param = poco("com.xpg.hssychargingpole:id/tvConfig").get_text()
        # 通讯方式
        pile_tv = ""
        if poco("com.xpg.hssychargingpole:id/tvFree").exists():
            pile_tv = poco("com.xpg.hssychargingpole:id/tvFree").get_text()
        # 充电价格
        pile_price = ""
        if poco("com.xpg.hssychargingpole:id/tv_ChargingDetail_ServicePrice").exists():
            pile_price = poco("com.xpg.hssychargingpole:id/tv_ChargingDetail_ServicePrice").get_text()

        if(poco("com.xpg.hssychargingpole:id/tv_ChargingDetail_invoice").exists()):
            # 上滑，获取车位信息
            poco.swipe([0.5, 0.8], [0.5, 0.5])
        else:
            # 上滑，获取车位信息
            poco.swipe([0.5, 0.8], [0.5, 0.35])
        # 营业时间
        pile_wt = ""
        weekTVs = poco("com.xpg.hssychargingpole:id/weekTV")
        tvTimes = poco("com.xpg.hssychargingpole:id/tvTime")
        for i in range(0, len(weekTVs)):
            pile_wt = pile_wt + weekTVs[i].get_text() + "," + tvTimes[i].get_text() + ";"


        # 车位类型
        pile_park = ""
        if poco("com.xpg.hssychargingpole:id/tv_ChargingDetail_parking").exists():
            pile_park = poco("com.xpg.hssychargingpole:id/tv_ChargingDetail_parking").get_text()
        # 桩主名称
        pile_owner = ""
        if poco("com.xpg.hssychargingpole:id/tvPileOwnerName").exists():
            pile_owner = poco("com.xpg.hssychargingpole:id/tvPileOwnerName").get_text()

        print(pile_name, pile_address, pile_type, pile_param, pile_tv, pile_price, pile_wt, pile_park, pile_owner)

        privatePile = PrivatePile(pile_name, pile_address, pile_type, pile_param, pile_tv, pile_price, pile_wt, pile_park, pile_owner)

        # 判断是否执行到最后一页了
        if privatePile.md5() in checkList:
            repeat = repeat + 1
            # 返回上一层
            poco("com.xpg.hssychargingpole:id/ib_ActivityChargingDetail_Back").click()
            continue

        reslist.append(privatePile)
        checkList.append(privatePile.md5())

        # 返回上一层
        poco("com.xpg.hssychargingpole:id/ib_ActivityChargingDetail_Back").click()

    if repeat >= 3:
        print('最后一页了')
        runSts = False
        break

    page = page + 1
    # 滑到下一页
    print('下一页', page)
    poco.swipe([0.5, 0.91], [0.5, 0.17])
    time.sleep(1)
