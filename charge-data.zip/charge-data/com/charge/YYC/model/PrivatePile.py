# -*- encoding=utf8 -*-
__author__ = "xuzhenghua"

import hashlib

# 私桩信息
class PrivatePile:
    def __init__(self, pile_name, pile_address, pile_type, pile_param, pile_tv, pile_price, pile_wt, pile_park, pile_owner):
        if pile_name is None:
            self.pile_name = ""
        else:
            self.pile_name = pile_name
        if pile_address is None:
            self.pile_address = ""
        else:
            self.pile_address = pile_address
        if pile_type is None:
            self.pile_type = ""
        else:
            self.pile_type = pile_type
        if pile_param is None:
            self.pile_param = ""
        else:
            self.pile_param = pile_param
        if pile_tv is None:
            self.pile_tv = ""
        else:
            self.pile_tv = pile_tv
        if pile_price is None:
            self.pile_price = ""
        else:
            self.pile_price = pile_price
        if pile_wt is None:
            self.pile_wt = ""
        else:
            self.pile_wt = pile_wt
        if pile_park is None:
            self.pile_park = ""
        else:
            self.pile_park = pile_park
        if pile_owner is None:
            self.pile_owner = ""
        else:
            self.pile_owner = pile_owner


    def md5(self):
        str = self.pile_name + self.pile_address + self.pile_type + self.pile_param + self.pile_tv + self.pile_price \
              + self.pile_wt + self.pile_park + self.pile_owner

        hl = hashlib.md5()
        hl.update(str.encode(encoding='utf-8'))
        return hl.hexdigest()


