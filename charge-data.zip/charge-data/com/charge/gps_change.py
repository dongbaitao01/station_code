# -*- encoding=utf8 -*-
__author__ = "xuzhenghua"

import requests
import json
from com.charge.domain.PrivatePileDo import private_pile

url = 'https://restapi.amap.com/v3/geocode/geo?output=JSON&key=c6ed0a985b9918d1e3dbf5a59712a3ea&address='

# data = requests.get(url + '海淀区安宁庄西路11号院宣海家园小区地上车位308号').json()
#
# print(data['geocodes'][0]['location'])


for pile in private_pile.select():
    try:
        data = requests.get(url + pile.pile_address + '&city=' + pile.city_name).json()
        gps = data['geocodes'][0]['location']
        print(pile.pile_address, gps)

        private_pile.update({private_pile.gps : gps}).where(private_pile.id == pile.id).execute()
    except Exception as e:
        print(e)
