# -*- encoding=utf8 -*-
__author__ = "xuzhenghua"

import requests

from selenium import webdriver
from html import unescape
from lxml import etree
from lxml import html
import json

# browser = webdriver.Chrome()

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument('--headless')
chrome_options.add_argument('--disable-gpu')
browser = webdriver.Chrome(chrome_options=chrome_options)

#header必须是以字典的形式出现
header = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36'}
brand_url = 'https://www.autohome.com.cn/ashx/index/GetHomeFindCar.ashx?type=1&brandid=33&v=1'
model_url = 'https://www.autohome.com.cn/ashx/index/GetHomeFindCar.ashx?type=2&seriesid=692&format=json&v=1'

detail_url = 'https://car.autohome.com.cn/config/spec/44083.html#pvareaid=3454541'

browser.get(detail_url)

# 品牌-型号
cars = requests.get(brand_url,headers=header,verify=False)
# 型号-版本
bt = requests.get(model_url,headers=header,verify=False)
# 详情
# dt = requests.get(detail_url,headers=header,verify=False)

print(cars.text)
print(bt.text)


tables = browser.find_element_by_class_name('tbset').find_elements_by_tag_name('td')

overall_score = browser.execute_script("return [...document.querySelectorAll('.carbox > div > a > span')].map(span => window.getComputedStyle(span,'before').content)") #key line in the problem

print(overall_score)

for ta in tables:
    # pt = ta.find_element_by_class_name('carbox').find_element_by_tag_name('div').find_elements_by_tag_name('span')[0].value_of_css_property('content')
    # nt = ta.find_element_by_class_name('carbox').find_element_by_tag_name('div').find_elements_by_tag_name('span')[1].value_of_css_property('content')

    at = ta.find_element_by_class_name('carbox').find_element_by_tag_name('div').find_element_by_tag_name('a')

    content = at.get_attribute('innerHTML')#.xpath('string(.)').replace('\n', ',').replace(' ', '')
    overall_scores = browser.execute_script("return [...document.querySelectorAll('.hs_kw51_confignj')].map(span => window.getComputedStyle(span,'before').content)[0]")

    element = etree.HTML(content)

    print(content)
    print(overall_scores)