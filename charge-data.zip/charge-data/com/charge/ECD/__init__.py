# -*- encoding=utf8 -*-
__author__ = "xuzhenghua"

from airtest.core.api import *
from airtest.cli.parser import cli_setup
from poco.drivers.android.uiautomation import AndroidUiautomationPoco

from com.charge.domain.PrivatePileDo import private_pile

poco = AndroidUiautomationPoco(use_airtest_input=True, screenshot_each_action=False)

if not cli_setup():
      auto_setup(__file__, logdir=True, devices=["android://127.0.0.1:5037/CUY0219531002973?cap_method=MINICAP&&ori_method=MINICAPORI&&touch_method=MAXTOUCH",])


# 当前页电站列表
pileList = poco("com.sgcc.evs.echarge:id/carItemLayout").wait(10)
print(len(pileList))

runSts = True
page = 1
last_piple = ''

while runSts:

    try:

        pileList = poco("com.sgcc.evs.echarge:id/carItemLayout").wait(10)

        lengtn = 4

        if len(pileList) < lengtn:
            lengtn = len(pileList)

        last = pileList[lengtn-1].offspring("com.sgcc.evs.echarge:id/stationNameTextView").get_text()
        # if last_piple == last:
        #     print('最后一页了')
        #     break
        # else:
        #     last_piple = last

        for num in range(0, lengtn):
            try:
                size = num
                # if page != 1:
                #     size = num + 1

                title = pileList[size].offspring("com.sgcc.evs.echarge:id/stationNameTextView").wait(10).get_text().replace(' ', '')
                # 查询是否存在
                pst_info = private_pile.get_or_none((private_pile.platform_name == 'e充电') & (
                            private_pile.pile_name == title))

                if pst_info is not None:
                    print('数据已存在，跳过')
                    continue

                # 点击进入详情
                pileList[size].offspring('com.sgcc.evs.echarge:id/stationNameTextView').click()

                poco.swipe([0.5, 0.7], [0.5, 0.3])

                pile_name = poco('com.sgcc.evs.echarge:id/stationNameTextView').wait(10).get_text().replace(' ', '')

                pile_address = ''
                if poco('com.sgcc.evs.echarge:id/stationAddress').exists():
                    pile_address = poco('com.sgcc.evs.echarge:id/stationAddress').wait(10).get_text()
                pile_price = ''
                if poco('com.sgcc.evs.echarge:id/acPriceTextView').exists():
                    pile_price = poco('com.sgcc.evs.echarge:id/acPriceTextView').wait(10).get_text()
                print(pile_name)
                print(pile_address)
                print(pile_price)

                pile_data_json = {'platform_name': 'e充电', 'pile_name': pile_name,
                                  'pile_address': pile_address, 'pile_type': "",
                                  'pile_param': "", 'pile_tv': "", 'pile_price': pile_price,
                                  'pile_wt': "",
                                  'pile_park': "", 'pile_owner': "",
                                  'city_name': "北京市", 'adname': "",
                                  'sname': ""}

                # 数据入库
                private_pile.insert(pile_data_json).execute()
            except Exception as e:
                print("拉取异常")
                print(repr(e))
            finally:
                try:
                    # 返回列表页
                    if poco("com.sgcc.evs.echarge:id/ivBack").exists():
                        poco("com.sgcc.evs.echarge:id/ivBack").click()
                    if poco("com.sgcc.evs.echarge:id/ivBack").exists():
                        poco("com.sgcc.evs.echarge:id/ivBack").click()
                except Exception as e1:
                    print("返回异常")
                    print(repr(e1))

        page = page + 1
        # 下滑到下一页
        poco.swipe([0.5, 0.916], [0.5, 0.264])
    except Exception as e2:
        print("异常")
        print(repr(e2))