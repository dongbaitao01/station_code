# -*- encoding=utf8 -*-
__author__ = "xuzhenghua"

from airtest.core.api import *
from airtest.cli.parser import cli_setup
from poco.drivers.android.uiautomation import AndroidUiautomationPoco
from com.charge.domain.StationInfo import *
from com.charge.domain.StationPrice import *
from com.charge.domain.PlatformStationInfo import *
from com.charge.kd.KDData import KDData
import sys
import codecs

poco = AndroidUiautomationPoco(use_airtest_input=True, screenshot_each_action=False)
#sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())

if not cli_setup():
      auto_setup(__file__, logdir=True, devices=["android://127.0.0.1:5037/4df1af08?cap_method=MINICAP&&ori_method=MINICAPORI&&touch_method=MAXTOUCH",])

# script content
print("start...")

# 查询总条数
count_num = station_info.select().count()
print("总条数：", count_num)

page_length = 10
pagesize = count_num // page_length
if count_num % page_length != 0:
    pagesize = pagesize + 1
print("总页数：", pagesize)


# 启动app
start_app("com.czb.charge")
# 判断是否有弹窗，有就关闭
if poco("com.czb.charge:id/iv_ad_close").exists():
    poco("com.czb.charge:id/iv_ad_close").click()

# 进入搜索页
poco(resourceId="com.czb.charge:id/tv_btn_search").click()

#分页查询
for page_num in range(1, pagesize):
    # 查询并循环当前页的数据
    for station in station_info.select().order_by(station_info.id.asc()).paginate(page_num, page_length):
        print(station.id, station.station_name)
        # 捕获异常，异常不中断
        try:
            # 已该站未点，获取附近的3个电站信息
            stations = KDData.getData(station)

            for st in stations:
                # 查询库中是否有记录
                pst_info = platform_station_info.get_or_none((platform_station_info.platform_name == '快电') & (platform_station_info.station_name == st.station_name))

                pst_id = None
                # 判断查询结果
                if(pst_info == None):
                    station_data_json = {'platform_name': '快电', 'brand_name': st.brand_name, 'station_name': st.station_name, 'quick_total': st.quick_total,
                                 'slow_total': st.slow_total, 'item_tag': st.item_tag, 'address': st.address, 'province_code': station.province_code,
                                         'province_name': station.province_name, 'city_code': station.city_code, 'city_name': station.city_name,
                                         'ad_code': station.ad_code, 'ad_name': station.ad_name,'search_name':station.station_name, 'search_id':station.id}
                    # 电站信息写入
                    pst_id = platform_station_info.insert(station_data_json).execute()
                else:
                    pst_id = pst_info.id

                for price in st.price:
                    data_json = {'price_type': '快电', 'station_id': pst_id, 'platform_name': st.station_name,
                                 'platform_address': st.address, 'price_time': price.time, 'total_price': price.total,
                                 'ele_price': price.price, 'service_price': price.service}
                    # 电站价格写入
                    station_price.insert(data_json).execute()

        except Exception as e:
            print("拉取异常，异常站：", station.id, station.station_name)
            print(repr(e))
            continue
