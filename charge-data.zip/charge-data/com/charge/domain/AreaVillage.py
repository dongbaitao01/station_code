# -*- encoding=utf8 -*-
__author__ = "xuzhenghua"

from peewee import *
from com.charge.domain.BaseModel import BaseModel


# 小区街道信息
class t_area_village(BaseModel):
    id = CharField()
    adcode = CharField()
    address = CharField()
    adname = CharField()
    cocode = CharField()
    coname = CharField()
    name = CharField()
    pcode = CharField()
    pname = CharField()
    scode = CharField()
    sname = CharField()
    parking = CharField()
    build_num = CharField()
    hourse_num = CharField()