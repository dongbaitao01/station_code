# -*- encoding=utf8 -*-
__author__ = "xuzhenghua"

from peewee import *
from com.charge.domain.BaseModel import BaseModel


# 共享私桩信息
class private_pile(BaseModel):
    id = IntegerField()
    platform_name = CharField()
    pile_name = CharField()
    pile_address = CharField()
    pile_type = CharField()
    pile_param = CharField()
    pile_tv = CharField()
    pile_price = CharField()
    pile_wt = CharField()
    pile_park = CharField()
    pile_owner = CharField()
    create_time = DateField()
    city_name = CharField()
    adname = CharField()
    sname = CharField()
    gps = CharField()