# -*- encoding=utf8 -*-
__author__ = "xuzhenghua"

from peewee import *
from com.charge.domain.BaseModel import BaseModel


# 平台电站信息
class platform_station_info(BaseModel):
    id = IntegerField()
    platform_name = CharField()
    brand_name = CharField()
    station_name = CharField()
    quick_total = IntegerField()
    slow_total = IntegerField()
    item_tag = CharField()
    address = CharField()
    province_code = CharField()
    province_name = CharField()
    city_code = CharField()
    city_name = CharField()
    ad_code = CharField()
    ad_name = CharField()
    gps = CharField()
    search_name = CharField()
    search_id = IntegerField()
    create_time = DateField()


st = platform_station_info.get_or_none((platform_station_info.platform_name == '快电') & (platform_station_info.station_name == '海淀区北四环内环辅路（40079）充电扬招站'))

print(st == None)