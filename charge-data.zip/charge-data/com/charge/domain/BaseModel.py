# -*- encoding=utf8 -*-
__author__ = "xuzhenghua"

from peewee import *
import peewee

database = peewee.MySQLDatabase(database='carrier', host='172.16.174.91', port=3306, user='carrier', password='carrier_sit', charset='utf8')


class BaseModel(Model):
    class Meta:
        database = database  # This domain uses the "carrier.db" database.