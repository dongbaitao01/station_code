# -*- encoding=utf8 -*-
__author__ = "xuzhenghua"

from peewee import *
from com.charge.domain.BaseModel import BaseModel


# 高德电站信息
class station_info(BaseModel):
    id = IntegerField()
    station_name = CharField()
    address = CharField()
    province_code = CharField()
    province_name = CharField()
    city_code = CharField()
    city_name = CharField()
    ad_code = CharField()
    ad_name = CharField()
    gps = CharField()
    create_time = DateField()