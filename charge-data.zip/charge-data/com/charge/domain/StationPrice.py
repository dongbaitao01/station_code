# -*- encoding=utf8 -*-
__author__ = "xuzhenghua"

from peewee import *
from com.charge.domain.BaseModel import BaseModel


# 电站价格
class station_price(BaseModel):
    id = IntegerField()
    price_type = CharField()
    station_id = IntegerField()
    platform_name = CharField()
    platform_address = CharField()
    price_time = CharField()
    total_price = DateTimeField()
    ele_price = DateTimeField()
    service_price = DateTimeField()
    create_time = DateField()