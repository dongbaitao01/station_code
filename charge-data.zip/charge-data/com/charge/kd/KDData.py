# -*- encoding=utf8 -*-
__author__ = "xuzhenghua"

from airtest.core.api import *
from poco.drivers.android.uiautomation import AndroidUiautomationPoco

from com.charge.model.Station import Station
from com.charge.model.StationPrice import StaionPrice
from com.charge.domain.PlatformStationInfo import *
import sys
import codecs
poco = AndroidUiautomationPoco(use_airtest_input=True, screenshot_each_action=False)
sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())


class KDData:

    def getData(station):
        # 点击搜索框
        if poco("转到上一层级").exists():
            poco("转到上一层级").click()
        if poco("com.czb.charge:id/iv_back").exists():
            poco("com.czb.charge:id/iv_back").click()
        if poco("com.czb.charge:id/inputTV").exists():
            poco("com.czb.charge:id/inputTV").click()

        # 按名称搜索
        poco(resourceId="com.czb.charge:id/et_search").set_text(station.station_name)
        poco(resourceId="com.czb.charge:id/et_search").click()
        touch(Template(r"image/tpl1628147063402.png", record_pos=(0.425, 0.856), resolution=(1080, 2340)))

        # 滑东到地址搜索栏
        poco.swipe([0.5, 0.8], [0.5, 0.2])

        # 未查询到结果，跳过
        if bool(1 - poco(name="android.view.ViewGroup").exists()):
            return[]

        # 点击第一个地址
        poco(name="android.view.ViewGroup").focus('center').click()

        # 无站点信息，跳过
        if bool(1 - poco(name="com.czb.charge:id/charge_item_station_card_root").exists()):
            return []

        # 获取按地址搜索到的集合
        search_list = poco(name="com.czb.charge:id/charge_item_station_card_root")
        stations = []
        for count in range(0, 10):

            tag_num = 1
            if count == 0:
                tag_num = 0


            st_name = search_list[tag_num].child("com.czb.charge:id/cl_content_layout").child(
                "com.czb.charge:id/tv_station_name").get_text()
            st_adr = search_list[tag_num].child("android.widget.FrameLayout").offspring(
                "com.czb.charge:id/tv_address").get_text()
            # print(st_name)
            # print(st_adr)
            # 查询库中是否有记录
            pst_info = platform_station_info.get_or_none(
                (platform_station_info.platform_name == '快电') & (platform_station_info.station_name == st.station_name))

            end_zb = 0.55

            # 存在记录，跳过
            if(pst_info != None):
                poco.swipe([0.5, 0.8], [0.5, end_zb])
                continue

            brand_name = search_list[0].offspring("com.czb.charge:id/tv_station_source_name").get_text()
            # print(brand_name)

            kq_num = 0
            if search_list[tag_num].offspring("com.czb.charge:id/tv_quick_total_amount").exists():
                kq_num = search_list[tag_num].offspring("com.czb.charge:id/tv_quick_total_amount").get_text().replace("共", "")
                # print(kq_num)
            mq_num = 0
            if search_list[tag_num].offspring("com.czb.charge:id/tv_slow_total_amount").exists():
                mq_num = search_list[tag_num].offspring("com.czb.charge:id/tv_slow_total_amount").get_text().replace("共", "")
                #print(mq_num)

            tag = ''

            if (search_list[tag_num].offspring("com.czb.charge:id/tv_item_tag").exists()):
                tag_list = search_list[tag_num].offspring("com.czb.charge:id/tv_item_tag")
                for num2 in range(0, len(tag_list)):

                    if num2 == 0:
                        tag = tag_list[num2].get_text()
                    else:
                        tag = tag_list[num2].get_text() + ',' + tag

            # print(tag)

            # 点击进入详情页
            search_list[tag_num].child("com.czb.charge:id/cl_content_layout").focus('center').click()
            # 进入价格详情
            poco(name='com.czb.charge:id/priceDetailLL').click()

            # 获取价格内容
            obj_list = poco("com.czb.charge:id/rv_time_price").child("android.widget.FrameLayout")
            reslist = []

            forsize = 7
            if len(obj_list) < 7:
                forsize = len(obj_list)

            # 先获取前7条
            for num in range(0, forsize):
                time = obj_list[num].child("android.widget.LinearLayout").child("com.czb.charge:id/timeTV").get_text()
                total = obj_list[num].child("android.widget.LinearLayout").child("android.widget.LinearLayout").child(
                    "com.czb.charge:id/kdPriceTV").get_text()
                price = obj_list[num].child("android.widget.LinearLayout").child("android.widget.LinearLayout").child(
                    "com.czb.charge:id/priceTV").get_text()
                service = obj_list[num].child("android.widget.LinearLayout").child("android.widget.LinearLayout").child(
                    "com.czb.charge:id/serviceTV").get_text()
                staionPrice = StaionPrice(time, total, price, service)
                reslist.append(staionPrice)

            if len(obj_list) > 7:
                # 滑到下一页
                poco.swipe([0.5, 0.95], [0.5, 0.15])
                # 获取价格内容
                obj_list2 = poco("com.czb.charge:id/rv_time_price").child("android.widget.FrameLayout")
                for num in range(1, len(obj_list2)):
                    time = obj_list2[num].child("android.widget.LinearLayout").child(
                        "com.czb.charge:id/timeTV").get_text()
                    total = obj_list2[num].child("android.widget.LinearLayout").child(
                        "android.widget.LinearLayout").child("com.czb.charge:id/kdPriceTV").get_text()
                    price = obj_list2[num].child("android.widget.LinearLayout").child(
                        "android.widget.LinearLayout").child("com.czb.charge:id/priceTV").get_text()
                    service = obj_list2[num].child("android.widget.LinearLayout").child(
                        "android.widget.LinearLayout").child("com.czb.charge:id/serviceTV").get_text()
                    staionPrice = StaionPrice(time, total, price, service)
                    reslist.append(staionPrice)

            station = Station(st_name, st_adr, brand_name, kq_num, mq_num, tag, reslist)
            stations.append(station)
            poco("转到上一层级").click()
            poco("com.czb.charge:id/layout_back").click()

            poco.swipe([0.5, 0.8], [0.5, end_zb])

        return stations