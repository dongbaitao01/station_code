# -*- encoding=utf8 -*-
__author__ = "xuzhenghua"

from airtest.core.api import *
from airtest.cli.parser import cli_setup
from poco.drivers.android.uiautomation import AndroidUiautomationPoco
from com.charge.domain.AreaVillage import t_area_village
from com.charge.YYC.yyc_data import yyc
import sys
import codecs

poco = AndroidUiautomationPoco(use_airtest_input=True, screenshot_each_action=False)
#sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())

if not cli_setup():
      auto_setup(__file__, logdir=True, devices=["android://127.0.0.1:5037/4df1af08?cap_method=MINICAP&&ori_method=MINICAPORI&&touch_method=MAXTOUCH",])


start_app("com.xpg.hssychargingpole")

# 关闭弹窗
if poco("com.xpg.hssychargingpole:id/tipsClose").exists():
    poco("com.xpg.hssychargingpole:id/tipsClose").click()

# 进入搜索页
poco("com.xpg.hssychargingpole:id/tv_Index_search").click()

# 查询街道信息
for pile in t_area_village.select().order_by(t_area_village.sname.asc()).group_by(t_area_village.sname).limit(900).offset(33):
    print('街道名称:', pile.id, pile.sname)
    try:
        yyc.getData(pile)
    except Exception as e:
        print("拉取异常，异常街道：", pile.sname)
        print(repr(e))
    print('结束：', pile.sname)