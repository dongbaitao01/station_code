# -*- encoding=utf8 -*-
__author__ = "xuzhenghua"

import requests

from selenium import webdriver
from html import unescape
from lxml import etree
from lxml import html
import json

import urllib3
urllib3.disable_warnings()


#header必须是以字典的形式出现
header = {'Content-Type': 'application/json; charset=UTF-8', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36'}
brand_url = 'https://openapi.diandong.com/car/brandList?energy_type=all&brand_all=1'
model_url = 'https://openapi.diandong.com/car/bSerieList/18/1/999'

base_url = 'https://asg.diandong.com/car/series/919/base.json'
ext_url = 'https://asg.diandong.com/car/series/919/extdata.json'
car_dt_url = 'https://asg.diandong.com/car/series/919/0/carParamValue.json'

# 品牌-型号
brand = requests.get(brand_url, headers=header, verify=False)

# 型号-版本
model = requests.get(model_url, headers=header, verify=False)

# 汽车参数-基础信息
base = requests.get(base_url, headers=header, verify=False)
# 汽车参数-扩张信息
ext = requests.get(ext_url, headers=header, verify=False)
# 汽车参数-详细信息
car_dt = requests.get(car_dt_url, headers=header, verify=False)

print(brand.json())
print(model.json())
print(base.json())
print(ext.json())
print(car_dt.json())

