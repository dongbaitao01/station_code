# -*- encoding=utf8 -*-
__author__ = "xuzhenghua"


class StaionPrice:
    def __init__(self, time, total, price, service):
        self.time = time
        self.total = total
        self.price = price
        self.service = service