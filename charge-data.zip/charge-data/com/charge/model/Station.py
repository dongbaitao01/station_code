# -*- encoding=utf8 -*-
__author__ = "xuzhenghua"


class Station:
    def __init__(self, station_name, address, brand_name, quick_total, slow_total, item_tag, price):
        self.station_name = station_name
        self.address = address
        self.brand_name = brand_name
        self.quick_total = quick_total
        self.slow_total = slow_total
        self.item_tag = item_tag
        self.price = price